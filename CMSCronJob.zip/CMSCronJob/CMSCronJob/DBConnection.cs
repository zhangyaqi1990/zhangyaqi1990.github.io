﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace CMSCronJob
{
    public class DBConnection : IDisposable
    {
        //        private DBConnection()
        //        {
        //        }
        //
        //        private string databaseName = string.Empty;
        //        public string DatabaseName
        //        {
        //            get { return databaseName; }
        //            set { databaseName = value; }
        //        }
        //
        //        public string Password { get; set; }
        //        private MySqlConnection connection = null;
        //        public MySqlConnection Connection
        //        {
        //            get { return connection; }
        //        }
        //
        //        private static DBConnection _instance = null;
        //        public static DBConnection Instance()
        //        {
        //            if (_instance == null)
        //                _instance = new DBConnection();
        //            return _instance;
        //        }
        //
        //        public bool IsConnect()
        //        {
        //            bool result = true;
        //            if (Connection == null)
        //            {
        //                if (String.IsNullOrEmpty(databaseName))
        //                    result = false;
        //                string connstring = string.Format("Server=localhost; database={0}; UID=root; password=root", databaseName);
        //                connection = new MySqlConnection(connstring);
        //                connection.Open();
        //                result = true;
        //            }
        //
        //            return result;
        //        }
        //
        //        public void Close()
        //        {
        //            connection.Close();
        //        }
        //
        //        public void Dispose()
        //        {
        //            _instance.Dispose();
        //            connection.Dispose();
        //        }

        private string host = "localhost";
        private int port = 3306;
        private string uid = "root";
        private string password = "root";
        private string dbname = "wp";

        MySqlConnection conn = null;

        //private constructor
        private DBConnection()
        {
            string connStr = "server=" + host
                             + ";port=" + port
                             + ";uid=" + uid
                             + ";password=" + password
                             + ";database=" + dbname;
            conn = new MySqlConnection(connStr);
        }

        //single instance
        public static readonly DBConnection Instance = new DBConnection();

        //connect db
        public Boolean ConnectToDB()
        {
            if (conn == null)
                return false;
            if (conn.State == System.Data.ConnectionState.Open)
                return true;
            try
            {
                conn.Open();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }

        public DataTable GetDataTable(string sql)
        {
            if (conn != null)
            {
                if (conn.State == System.Data.ConnectionState.Open || ConnectToDB())
                {
                    MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
                    DataSet MyDataSet = new DataSet();
                    da.Fill(MyDataSet);
                    return MyDataSet.Tables[0];
                }
            }
            return null;
        }

        /**
         * @brief   Executes the SQL operation.
         *          
         * @param   sql The SQL cmd.
         * @return  row numbers affected.
        **/

        public Boolean runSql(String sql)
        {
            if (conn != null)
            {
                if (conn.State == System.Data.ConnectionState.Open || ConnectToDB())
                {
                    try
                    {
                        MySqlCommand cmd = new MySqlCommand(sql, conn);

                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception)
                    {
                        
                        throw;
                    }
                    
                }
            }
            return true;
        }

        public Boolean InsertJsonArrayWithTransaction<T>(T data)
        {
            if (conn != null)
            {
                if (conn.State == System.Data.ConnectionState.Open || ConnectToDB())
                {
                    try
                    {
                        MySqlCommand cmd = new MySqlCommand(sql, conn);

                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                }
            }
            return true;
        }

        public void Close()
        {
            conn.Close();
        }

        public void Dispose()
        {
            if (conn != null)
            {
                conn.Dispose();
                conn = null;
            }
        }
    }
}
