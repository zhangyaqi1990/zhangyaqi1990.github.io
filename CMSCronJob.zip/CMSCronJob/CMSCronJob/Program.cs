﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using RestSharp;

namespace CMSCronJob
{
    class Program
    {
        public const int FAILED = -1;
        public const int IN_PROCESS = 0;
        public const int SUCCESS = 1;

        public const string DB_NAME = "wp";
        public const string DB_TABLE = "wp_dst";


        // pass some useful information from wordpress into the args array, 
        // like the person who execute the job, datetime...TBD
        static int Main(string[] args)
        {

            // separate main process into three parts
            // 1. Get data from DST system.
            // 2. Store DST data into WordPress mysql database.
            // 3. Post DST data to MyLearning.

            if (checkIsJobRunning())
            {
                return IN_PROCESS;
            }

            string dstDataString = getDataFromDST();

            if (!validateData(dstDataString))
            {
                return FAILED;
            }

            storeDataToDatabase(dstDataString);

            return SUCCESS;
        }


        static bool checkIsJobRunning()
        {
            return System.Diagnostics.Process.GetProcessesByName("CronJob").ToList().Count > 0 ? true : false;
        }


        static string getDataFromDST()
        {
            var client = new RestClient("http://localhost:80");
            var request = new RestRequest("dstData.json", Method.GET);

            IRestResponse response = client.Execute(request);
            if (response.ErrorException != null)
            {
                // recode in db
                return null;
            }

            
            if (response.StatusCode != HttpStatusCode.OK)
            {
                //record in db
                return null;
            }

            return response.Content;
        }

        static bool validateData(string dstDataString)
        {
            if (dstDataString == null)
            {
                return false;
            }

            try
            {
                DstData[] a = JsonConvert.DeserializeObject<DstData[]>(dstDataString);
            }
            catch (Exception e)
            {
                // record in db
                return false;
            }

            return true;
        }

        static bool storeDataToDatabase(string dstDatas)
        {
            using (var dbCon = DBConnection.Instance)
            {

                try
                {
                    Boolean aa = dbCon.InsertJsonArrayWithTransaction(JsonConvert.DeserializeObject<DstData[]>(dstDatas));
                    string query = "Insert into " + DB_TABLE;
//                    dbCon.runSql();


//                        while (reader.Read())
//                        {
//                            string someStringFromColumnZero = reader.GetString(0);
//                            string someStringFromColumnOne = reader.GetString(1);
//                            Console.WriteLine(someStringFromColumnZero + "," + someStringFromColumnOne);
//                        }
//                        Console.ReadLine();

                }
                catch (Exception)
                {
                    //record to db
                    return false;
                }
                
            }

            return true;
        }


        static bool postDataToMyLearning(string[] args)
        {
            string[] postArgs = { "test", "test", "publish" };
            if (args.Length > 0)
            {
                postArgs = args;
            }
            using (var wb = new WebClient())
            {
                var data = new NameValueCollection();
                data["title"] = postArgs[0];
                data["content"] = postArgs[1];
                data["status"] = postArgs[2];

                wb.Headers.Add("Authorization", "Basic YWRtaW46YWRtaW4=");

                var url = "http://localhost:80/ILC_CMS/wp/wp-json/wp/v2/posts";
                var response = wb.UploadValues(url, "POST", data);

                return true;
            }
            return true;
        }

    }
}
