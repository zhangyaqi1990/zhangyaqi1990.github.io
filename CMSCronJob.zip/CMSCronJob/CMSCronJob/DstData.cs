﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMSCronJob
{
    class DstData
    {
        public string SessionName { get; set; }
        public string SessionState { get; set; }
        public string SessionCode { get; set; }
        public string FacilityName { get; set; }
        public string SessionStartDT { get; set; }
        public string SessionEndDT { get; set; }
        public string TimeZone { get; set; }
        public string FacultyCount { get; set; }
        public string LocationName { get; set; }
        public string LocationStartDT { get; set; }
        public string LocationEndDT { get; set; }
        public string VenueName { get; set; }
        public bool DoNotDisplay { get; set; }
    }
}